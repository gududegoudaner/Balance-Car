#include "sys.h"


float Pitch,Roll,Yaw;
short gyrox,gyroy,gyroz;				//������--���ٶ�
short aacx,aacy,aacz;						//���ٶ�
int Encoder_Left,Encoder_Right;	//���������ݣ��ٶȣ�
//float Target_Speed=2;


int PWM_MAX=7200,PWM_MIN=-7200;	//PWM�޷�����
int MOTO1,MOTO2;								//���װ�ر���
int main(void)
{
	All_Init();
	
	
	while (1)
	{
		//Load(65535,65535);
		
		//MPU6050_DMP_Get_Data(&Pitch,&Roll,&Yaw);
		//MPU_Get_Gyroscope(&gyrox,&gyroy,&gyroz);
//		MPU_Get_Accelerometer(&ax,&ay,&az);
		OLED_ShowSignedNum(3, 1, Pitch, 3);
		OLED_ShowSignedNum(3, 5, Roll, 3);
		OLED_ShowSignedNum(3, 9, Yaw, 3);
		
//		OLED_ShowSignedNum(2, 8, gyrox, 5);
//		OLED_ShowSignedNum(3, 8, gyroy, 5);
//		OLED_ShowSignedNum(4, 8, gyroz, 5);
		OLED_ShowSignedNum(1, 1, MOTO1, 4);
		OLED_ShowSignedNum(1, 6, MOTO2, 4);
		OLED_ShowSignedNum(2, 1, Read_Speed(2), 4);
		OLED_ShowSignedNum(2, 7, Read_Speed(4), 4);
		
//		int i=0;
//		OLED_ShowNum(4, 1,i,1);
//		OLED_ShowNum(4, 5,Target_Speed,1);
//		i++;
//		if(i%10000==0)
//			Target_Speed*=-1;
	}
}
