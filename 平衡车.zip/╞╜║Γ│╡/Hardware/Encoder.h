#ifndef __Encoder_H
#define __Encoer_H

void Encoder_TIM2_Init(void);
void Encoder_TIM4_Init(void);
int Read_Speed(int TIMx);

#endif
