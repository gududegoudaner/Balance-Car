#ifndef __Motor_H
#define __Motor_H

#define Ain1  PBout(12)
#define Ain2  PBout(13)
#define Bin1  PBout(14)
#define Bin2  PBout(15)

void Motor_Init(void);
 
void Limit(int *motoA,int *motoB);
 
int abs(int p);

void Load(int moto1,int moto2);

#endif


