#ifndef __Control_H
#define __Control_H

int Vertical(float Med,float Angle,float gyro_X);
int Velocity(int Target,int encoder_left,int encoder_right);
int Turn(int gyro_Z,int RC);
void EXTI9_5_IRQHandler(void);

#endif
